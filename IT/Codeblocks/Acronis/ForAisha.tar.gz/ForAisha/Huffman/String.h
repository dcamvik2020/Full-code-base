#include <string>

void Reverse(std::string& tmp);
int my_strcmp(const std::string& s1, const std::string& s2);
int my_strncmp(const std::string& s1, const std::string& s2 , unsigned len);
bool is_null(const std::string& s);
